nohup python3 server.py & 
